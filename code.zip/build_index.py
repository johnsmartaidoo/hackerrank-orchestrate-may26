import os
import json
import re

def clean_text(text):
    # Remove markdown links, images, and extra whitespace
    text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', text)
    text = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def build_index(base_dir):
    index = []
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            if file.endswith('.md'):
                path = os.path.join(root, file)
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Extract title from filename or first line
                        title = file.replace('.md', '').replace('-', ' ')
                        # Simple cleanup
                        clean_content = clean_text(content)
                        index.append({
                            'path': path,
                            'title': title,
                            'content': clean_content,
                            'domain': 'hackerrank' if 'hackerrank' in path else ('claude' if 'claude' in path else 'visa')
                        })
                except Exception as e:
                    print(f"Error reading {path}: {e}")
    return index

if __name__ == "__main__":
    base_path = 'hackerrank-orchestrate-may26/data'
    corpus = build_index(base_path)
    with open('corpus_index.json', 'w', encoding='utf-8') as f:
        json.dump(corpus, f, indent=2)
    print(f"Indexed {len(corpus)} documents.")
