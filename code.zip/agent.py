import os
import json
import csv
import re
from openai import OpenAI

client = OpenAI()

# Load the corpus
with open('corpus_index.json', 'r') as f:
    corpus = json.load(f)

def search_corpus(query, domain=None, top_k=5):
    # Simple keyword search for demonstration
    # In a real scenario, we'd use embeddings or BM25
    query_words = set(re.findall(r'\w+', query.lower()))
    results = []
    for doc in corpus:
        if domain and doc['domain'] != domain.lower():
            continue
        
        score = 0
        content_lower = doc['content'].lower()
        title_lower = doc['title'].lower()
        
        for word in query_words:
            if word in title_lower:
                score += 10
            if word in content_lower:
                score += 1
        
        if score > 0:
            results.append((score, doc))
    
    results.sort(key=lambda x: x[0], reverse=True)
    return [doc for score, doc in results[:top_k]]

def triage_issue(issue, subject, company):
    # Determine if we should escalate or reply
    # We'll use the LLM to decide based on the issue and retrieved docs
    
    domain = company.lower() if company and company.lower() in ['hackerrank', 'claude', 'visa'] else None
    relevant_docs = search_corpus(f"{subject} {issue}", domain=domain)
    
    context = "\n\n".join([f"Source: {doc['path']}\nContent: {doc['content'][:1000]}" for doc in relevant_docs])
    
    prompt = f"""
You are a support triage agent for HackerRank, Claude, and Visa.
Based on the following support ticket and the provided support documentation, determine the best course of action.

Support Ticket:
Company: {company}
Subject: {subject}
Issue: {issue}

Relevant Support Documentation:
{context}

Your task:
1. Identify the Request Type (e.g., product_issue, bug, billing, fraud, invalid, etc.)
2. Classify the Product Area (e.g., screen, community, privacy, travel_support, general_support, etc.)
3. Decide Status: 'Replied' or 'Escalated'.
   - Escalate if: high-risk, sensitive (fraud, major security), unsupported cases, or if no clear answer is in the docs.
   - Reply if: a clear, safe, grounded answer exists in the docs.
4. Generate the Response:
   - If 'Replied', provide a safe, grounded response based ONLY on the docs.
   - If 'Escalated', explain why (e.g., "Escalate to a human").
   - If the request is out of scope or invalid, say "I am sorry, this is out of scope from my capabilities".

Output in JSON format:
{{
  "request_type": "...",
  "product_area": "...",
  "status": "...",
  "response": "..."
}}
"""

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "system", "content": "You are a helpful support triage agent."},
                  {"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    
    return json.loads(response.choices[0].message.content)

def process_tickets(input_file, output_file, log_file):
    with open(input_file, 'r', encoding='utf-8') as f_in, \
         open(output_file, 'w', encoding='utf-8', newline='') as f_out, \
         open(log_file, 'w', encoding='utf-8') as f_log:
        
        reader = csv.DictReader(f_in)
        fieldnames = ['Issue', 'Subject', 'Company', 'Response', 'Product Area', 'Status', 'Request Type']
        writer = csv.DictWriter(f_out, fieldnames=fieldnames)
        writer.writeheader()
        
        for row in reader:
            issue = row.get('Issue', '')
            subject = row.get('Subject', '')
            company = row.get('Company', '')
            
            print(f"Processing: {subject} ({company})")
            f_log.write(f"USER: {issue}\n")
            
            try:
                result = triage_issue(issue, subject, company)
                
                output_row = {
                    'Issue': issue,
                    'Subject': subject,
                    'Company': company,
                    'Response': result['response'],
                    'Product Area': result['product_area'],
                    'Status': result['status'],
                    'Request Type': result['request_type']
                }
                writer.writerow(output_row)
                f_log.write(f"AGENT: {result['response']}\n\n")
            except Exception as e:
                print(f"Error processing ticket: {e}")
                writer.writerow({
                    'Issue': issue,
                    'Subject': subject,
                    'Company': company,
                    'Response': "Error processing request.",
                    'Product Area': "",
                    'Status': "Escalated",
                    'Request Type': "error"
                })

if __name__ == "__main__":
    input_csv = 'hackerrank-orchestrate-may26/data/support_tickets/support_tickets.csv'
    output_csv = 'output.csv'
    log_txt = 'log.txt'
    process_tickets(input_csv, output_csv, log_txt)
